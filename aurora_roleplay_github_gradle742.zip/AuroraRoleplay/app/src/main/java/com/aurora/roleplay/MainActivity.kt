package com.aurora.roleplay

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val SERVER_IP = "188.165.192.24:5644" // embedded server IP

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val splash: ImageView = findViewById(R.id.splashImage)
        splash.setImageResource(R.drawable.splash_image)

        val tv: TextView = findViewById(R.id.serverIp)
        val prefs = getSharedPreferences("aurora_prefs", Context.MODE_PRIVATE)
        val stored = prefs.getString("server_ip", SERVER_IP) ?: SERVER_IP
        tv.text = "Servidor: $stored"

        if (!prefs.contains("server_ip")) {
            prefs.edit().putString("server_ip", SERVER_IP).apply()
        }

        val btnConnect: Button = findViewById(R.id.btnConnect)
        btnConnect.setOnClickListener {
            val url = "samp://${SERVER_IP}"
            try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                startActivity(intent)
            } catch (e: Exception) {
                AlertDialog.Builder(this)
                    .setTitle("Conectar")
                    .setMessage("Tente conectar manualmente pelo IP:\n$SERVER_IP")
                    .setPositiveButton("OK", null)
                    .show()
            }
        }
    }
}