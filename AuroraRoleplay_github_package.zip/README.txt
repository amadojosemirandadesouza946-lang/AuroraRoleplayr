Aurora Roleplay - GitHub-ready project
