package com.aurora.roleplay;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextView tv = new TextView(this);
        tv.setText("AURORA ROLEPLAY - Server: 188.165.192.24:5644");
        setContentView(tv);
    }
}
